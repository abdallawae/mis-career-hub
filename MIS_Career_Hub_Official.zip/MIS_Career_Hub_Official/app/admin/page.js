"use client";
import {useEffect,useState} from "react";
import {supabase} from "../../lib/supabase";
export default function Admin(){
 const [courses,setCourses]=useState([]),[title,setTitle]=useState(""),[description,setDescription]=useState(""),[category,setCategory]=useState("General"),[msg,setMsg]=useState("");
 async function load(){if(!supabase)return;const {data}=await supabase.from("courses").select("*").order("id");setCourses(data||[])}
 useEffect(()=>{load()},[]);
 async function add(e){e.preventDefault();if(!supabase)return setMsg("أضف إعدادات Supabase أولًا.");const {error}=await supabase.from("courses").insert({title,description,category});if(error)setMsg("❌ "+error.message);else{setTitle("");setDescription("");setMsg("✅ تم إضافة الكورس");load()}}
 async function del(id){await supabase.from("courses").delete().eq("id",id);load()}
 return <main><nav><b>MIS <span>Career Hub</span> 👑</b><a href="/">عرض الموقع</a></nav><section className="adminpage"><h1>👨‍💻 لوحة التحكم</h1><div className="grid two"><div className="form"><h2>إضافة كورس</h2><form onSubmit={add}><input value={title} placeholder="اسم الكورس" onChange={e=>setTitle(e.target.value)} required/><textarea value={description} placeholder="وصف الكورس" onChange={e=>setDescription(e.target.value)} required/><input value={category} placeholder="التصنيف" onChange={e=>setCategory(e.target.value)}/><button>➕ إضافة</button></form><p>{msg}</p></div><div><h2>الكورسات الحالية</h2>{courses.map(c=><div className="item" key={c.id}><b>{c.title}</b><button onClick={()=>del(c.id)}>حذف</button></div>)}</div></div></section></main>
}