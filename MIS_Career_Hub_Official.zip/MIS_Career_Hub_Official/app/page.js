"use client";
import {useEffect,useState} from "react";
import {supabase} from "../lib/supabase";

const paths=[
["📊","Data Analyst","Excel → SQL → Power BI → Portfolio"],
["💼","Business Analyst","Business Analysis → Requirements → BPMN"],
["🖥️","Systems Analyst","Systems → UML → Documentation"],
["🗄️","Database Specialist","SQL → Database Design → Projects"],
["💻","Web Developer","HTML → CSS → JavaScript"],
["🤖","AI & Data","Python → Data → Machine Learning"]
];

export default function Home(){
 const [courses,setCourses]=useState([]);
 useEffect(()=>{if(supabase) supabase.from("courses").select("*").order("id").then(({data})=>setCourses(data||[]))},[]);
 return <main>
 <nav><b>MIS <span>Career Hub</span> 🚀</b><div><a href="#courses">الكورسات</a><a href="#paths">المسارات</a><a href="/login">تسجيل الدخول</a><a className="admin" href="/admin">لوحة التحكم</a></div></nav>
 <header className="hero"><div><small>🎓 منصة لطلاب نظم المعلومات الإدارية</small><h1>ابنِ مستقبلك مع <span>MIS Career Hub</span></h1><p>تعلم المهارات المطلوبة في سوق العمل، اختر مسارك، وابنِ Portfolio يساعدك على الحصول على فرصة.</p><a className="button" href="#paths">ابدأ رحلتك 🚀</a></div><aside><h2>طريقك للوظيفة 💼</h2><p>تعلم المهارة ✅</p><p>طبّق عمليًا ✅</p><p>ابنِ مشاريع ✅</p><p>جهّز CV وLinkedIn ✅</p></aside></header>
 <section id="courses"><h2>📚 الكورسات</h2><div className="grid">{courses.map(c=><article className="card" key={c.id}><h3>{c.title}</h3><p>{c.description}</p><small>{c.category}</small></article>)}</div>{!supabase&&<p className="notice">⚙️ اربط Supabase لتشغيل قاعدة البيانات الحقيقية.</p>}</section>
 <section id="paths"><h2>🧭 المسارات الوظيفية</h2><div className="grid">{paths.map((p,i)=><article className="card" key={i}><div className="icon">{p[0]}</div><h3>{p[1]}</h3><p>{p[2]}</p></article>)}</div></section>
 <section><h2>💼 الوظائف والمشاريع</h2><div className="grid"><article className="card"><h3>Junior Data Analyst</h3><p>ابدأ بتحليل البيانات وبناء Dashboards.</p></article><article className="card"><h3>Business Analyst</h3><p>حل مشاكل الشركات وتحليل المتطلبات.</p></article><article className="card"><h3>Portfolio Projects</h3><p>نفذ مشاريع حقيقية وضعها في Portfolio.</p></article></div></section>
 <footer>© 2026 MIS Career Hub — Learn • Build • Grow • Get Hired</footer>
 </main>
}